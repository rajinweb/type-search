import React from 'react';

const PlanetInfo= (props) => {
    return (
      <div className="modal" style={{background:'rgba(0,0,0,.6)', display:props.show ? "block" : "none"}}>
       <div className="modal-dialog">
        <div className="modal-content">
            <div className="modal-body">
            <h5 className="modal-title">Welcome to planet <b>{props.children.name}</b></h5>
            <p>It has a population of <b>{props.children.population}</b>.</p>
            <p>With Rotation period of <b>{props.children.rotation_period} days</b> &amp; Orbital period of <b>{props.children.orbital_period} days</b></p>
            <button className="btn btn-danger" onClick={props.handleClose}>Close</button>
            </div>
        </div>
        </div>
        </div>
     
  );
}
export default PlanetInfo;