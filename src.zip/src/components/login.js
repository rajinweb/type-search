import React, { Component } from 'react';
import '../css/login.css';
class Login extends Component {

  state = {
    username : "",
    password : "",
    errorMessage : "",
    
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-9 col-md-7 col-lg-5 mx-auto">
              <div className="card card-signin my-5">
                <div className="card-body">
                  <h5 className="card-title text-center">Member Login</h5>
                  <div className="form-signin">
                    <div className="form-label-group">
                      <input className='form-control' id="userName" type='text' onChange={event => this.setState({username : event.target.value})} placeholder='User Name' required autoFocus/>
                      <label htmlFor="userName">User Name</label>
                    </div>
                    <div className="form-label-group">
                      <input className='form-control' type='password' id="pws" onChange={event => this.setState({password : event.target.value})} placeholder='Password' required/>
                      <label htmlFor="pws">Password</label>
                    </div>
                    <button className='btn btn-lg btn-primary btn-block text-uppercase' disabled={!(this.state.password && this.state.username)} onClick={this.onLogin}>Login</button>
                  </div>
              </div>
           </div>
          </div>
       </div>
      </div>
    );
  }

  onLogin = () => {
       
        fetch("https://swapi.co/api/people/?search=" + this.state.username)
        .then(response => {
          if (!response.ok) {
            throw Error(response.statusText);
          }
          return response.json()
        })
        .then(data => this.validateLogin(data.results))
        .catch(error => {
          this.setState({
            errorMessage : "Something went wrong. Please try again."
          })
        })
  }

  validateLogin = (users) => {
    var searchedUser = users.length === 1 ? users[0] : null
    if (searchedUser && searchedUser.name === this.state.username && searchedUser.birth_year === this.state.password) {
      localStorage.setItem('user', JSON.stringify(searchedUser));
      this.homeSceen()
      return
    }
    this.setState({
      errorMessage : "Username or Password not matching"
    })
  }

   homeSceen = () => {
    this.props.history.push("/")
  }

}

export default Login;
