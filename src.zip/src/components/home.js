import React, { lazy,Suspense,Component} from 'react';

const List = React.lazy(() => import('./planetList.js'));
const PlanetInfo = React.lazy(() => import('../containers/info.js'));

class Home extends Component {

  state = {
    planets: [],
    items: [],
    showInfoModal : false,
    errorMessage : "",
    selectedPlanet : {},
    nextPage : null,
    searchText: ""
  }

render() {
  const user = JSON.parse(localStorage.getItem('user'))
  return (
    <Suspense fallback={<div className="display-4 modal text-white" style={{display: 'flex',background: 'rgba(0,0,0,0.5)',justifyContent: 'center'}}><span className="modal-dialog-centered">Loging....</span></div>}>
      <PlanetInfo show = {this.state.showInfoModal} children = {this.state.selectedPlanet} handleClose = {() => this.setState({showInfoModal : false})} ></PlanetInfo>  
        <div className="container-fluid my-3">
          <div className="navbar row">
            <h5 className="text-warning">Welcome, {user.name}</h5>
            <button className="btn btn-danger" onClick={this.onLogout} >Logout</button>
          </div>
           <input type="text" className="form-control" placeholder="Search planets" onChange={(event) =>this.filterList(event.target.value)}/>
          <List items={this.state.items} onItemClick={this.onListItemClicked}/>
          <button className="btn btn-warning" disabled={!this.state.nextPage}  onClick={this.loadNextPage} >Load More</button>
        </div>
    </Suspense>
  );
}

  componentDidMount() {

    fetch("https://swapi.co/api/planets/")
      .then(response => {
        if (!response.ok) {
          throw Error(response.statusText);
        }
        return response.json()
      })
      .then(data => {
        this.populateList(data.results)
        this.setState({
          nextPage: data.next
        })
      })
      .catch(error => {
        this.setState({
          errorMessage: "Something went wrong. Please try again."
        })
      })
  }

  onListItemClicked = (selectedPlanet) => {
    this.setState({
      selectedPlanet: selectedPlanet,
      showInfoModal: true,
    })
  }

  populateList = (planets) => {
    this.setState({
      planets: planets,
      items : planets
    })
  }

  filterList = (value) => {
    var updatedList = this.state.planets;
    updatedList = updatedList.filter(function(item) {
      return item.name.toLowerCase().search(
        value.toLowerCase()) !== -1;
    });
    this.setState({
      items: updatedList,
      searchText: value
    });
  }

  loadNextPage = () => {
    
    if (!this.state.nextPage) {
      return
    }
    fetch(this.state.nextPage)
      .then(response => {
        if (!response.ok) {
          throw Error(response.statusText);
        }
        return response.json()
      })
      .then(data => {
        this.setState({
          planets: this.state.planets.concat(data.results),
          nextPage: data.next
        })
        this.filterList(this.state.searchText)
      })
      .catch(error => {
        this.setState({
          errorMessage: "Something went wrong. Please try again."
        })
      })
  }

  onLogout = () => {
    localStorage.removeItem('user');
    this.props.history.push("/login")
  }

}




export default Home;
