import { BrowserRouter as Router, Route, Redirect, Switch } from "react-router-dom";
import React, { lazy,Suspense,Component} from 'react';
const Login = React.lazy(() => import('./components/login'));
const Home = React.lazy(() => import('./components/home'));

class App extends Component {

  render() {
    return (
      <Router>
        <Suspense fallback={<div className="display-4 modal text-white" style={{display: 'flex',background: 'rgba(0,0,0,0.5)',justifyContent: 'center'}}><span className="modal-dialog-centered">Loging....</span></div>}>
        <Switch>
        <HomeRoute exact path="/" component={Home} />
        <LoginRoute path="/login" component={Login} />
        </Switch>
        </Suspense>
      </Router>
    );
  }

}

export const HomeRoute = ({ component: Component, ...rest }) => (
    <Route {...rest} render={props => ( localStorage.getItem('user')
            ? <Component {...props} />
            : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
    )} />
)

export const LoginRoute = ({ component: Component, ...rest }) => (
    <Route {...rest} render={props => (!localStorage.getItem('user')
            ? <Component {...props} />
            : <Redirect to={{ pathname: '/', state: { from: props.location } }} />
    )} />
)

export default App;
